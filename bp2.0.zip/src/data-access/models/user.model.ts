import mongoose from 'mongoose'
import { User } from '@/domain/user/user.schema'
import { v4 as uuidv4 } from 'uuid'


// Define the user schema
const userSchema = new mongoose.Schema<User>({
  userId: { type: String, default: uuidv4() },
  userName: { type: String, required: false }
})

export const userModel = mongoose.model<User>(
  'user',
  userSchema
)
