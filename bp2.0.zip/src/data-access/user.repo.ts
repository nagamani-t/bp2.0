import {
  createUserRequestDTO,
  deleteUserRequestParamSchema,
  readUserRequestParamSchema,
  UpdateUser
} from '@/domain/user/user.schema'
import { userModel } from './models/user.model'

const getUser = async () => {
  try {
    const user = await userModel.find({}) // Find all user
    return user
  } catch (error) {
    throw error
  }
}
const createUser = async (newUser: typeof createUserRequestDTO) => {
  return await userModel.create(newUser)
}

const updateUser = async (userId: string, user: UpdateUser) => {
  try {
    const updatedUser = await userModel.findOneAndUpdate(
      { userId: userId },
      {
        $set: {
          userName: user.userName
        }
      },
      { new: true } // This option returns the updated document
    ).lean()

    return updatedUser // Return the updated document
  } catch (err) {
    console.error(err)
    throw err // Rethrow the error so it can be handled elsewhere
  }
}

const deleteUser = async (
  userId: typeof deleteUserRequestParamSchema
) => {
  try {
    const user = await userModel.deleteOne({
      userId: userId
    })

    if (user) {
      return 'DELETED SUCESSFULLY'
    } else {
      return 'ERROR SOMETHING WRONG'
    }
  } catch (error) {
    throw error
  }
}

const getOneUser = async (
  userId: typeof readUserRequestParamSchema
) => {
  try {
    const user = await userModel.findOne({
      userId: userId
    })

    return user
  } catch (error) {
    throw error
  }
}

export {
  getUser,
  createUser,
  updateUser,
  deleteUser,
  getOneUser
}
