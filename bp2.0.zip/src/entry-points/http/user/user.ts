import {
  FastifyPluginAsyncTypebox,
  TypeBoxTypeProvider
} from '@fastify/type-provider-typebox'

import { getUserFastifySchema } from '@/domain/user/use-cases/get-user/get-user.schema'
import createUserUseCase from '@/domain/user/use-cases/create-user'
import { createUserFastifySchema } from '@/domain/user/use-cases/create-user/create-user.schema'
import getUserUseCase from '@/domain/user/use-cases/get-user/get-user.usecase'
import { updateUserFastifySchema } from '@/domain/user/use-cases/update-user/update-user.schema'
import updateUserUseCase from '@/domain/user/use-cases/update-user/update-user.usecase'
import { deleteUserFastifySchema } from '@/domain/user/use-cases/delete-user/delete-user.schema'
import deleteUserUseCase from '@/domain/user/use-cases/delete-user/delete-user.usecase'
import { getOneUserFastifySchema } from '@/domain/user/use-cases/getone-user/getone-user.schema'
import getOneUserUseCase from '@/domain/user/use-cases/getone-user/getone-user.usecase'


const user: FastifyPluginAsyncTypebox = async (
  fastify,
  opts
): Promise<void> => {
  fastify
    .withTypeProvider<TypeBoxTypeProvider>()
    .get('/', { schema: getUserFastifySchema }, async function () {
      const getAlluser = await getUserUseCase()
      return getAlluser
    })
    .post(
      '/',
      { schema: createUserFastifySchema },
      async function (request: any, reply) {
        const user = await createUserUseCase(request.body)
        return user
      }
    )
    .put(
      '/:userId',
      { schema: updateUserFastifySchema },
      async function (request: any, reply) {
        const userId = request.params.userId
        const userBody = request.body

        // Call the updateUserUseCase with the extracted parameters
        const updatedUser = await updateUserUseCase(
          userId,
          userBody
        )

        
        if (updatedUser) {
          reply.code(200).send(updatedUser)
        }



      }
    )
    .delete(
      '/:userId',
      { schema: deleteUserFastifySchema },
      async function (request: any, reply) {
        let userId = request.params.userId
        const user = await deleteUserUseCase(userId)

        return user
      }
    )
    .get(
      '/:userId',
      { schema: getOneUserFastifySchema },
      async function (request: any, reply) {
        let userId = request.params.userId
        const user = await getOneUserUseCase(userId)
        return user
      }
    )
}

export default user
