export { default } from "./get-example.usecase";
export * from "./get-example.schema";
