export { default } from "./getone-example.usecase";
export * from "./getone-example.schema";
