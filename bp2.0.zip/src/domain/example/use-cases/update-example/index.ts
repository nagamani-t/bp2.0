export { default } from "./update-example.usecase";
export * from "./update-example.schema";
