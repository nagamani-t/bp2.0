export { default } from "./delete-example.usecase";
export * from "./delete-example.schema";
